#!/bin/bash

zip OCICommands package.sh test.sh  iam.py main.py  resource_search.py util.py